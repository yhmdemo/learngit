package com.sg.common;

public interface CommonConstant {

    public static final int COUNT_A = 3;
}
