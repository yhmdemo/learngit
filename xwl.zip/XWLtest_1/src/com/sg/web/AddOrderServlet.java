package com.sg.web;

import com.sg.domain.Order;
import com.sg.domain.User;
import com.sg.service.OrderService;
import com.sg.service.OrderServiceImpl;
import com.sg.util.Util_c3p0;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * Created by Kiss on 2018/11/26 0026.
 */
public class AddOrderServlet extends HttpServlet {

    private OrderService orderService = new OrderServiceImpl();

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        String resultInfo = "";
        String sendName = request.getParameter("sendName");
        String sendTel = request.getParameter("sendTel");
        String sendAddr = request.getParameter("sendAddr");

        String recvName = request.getParameter("recvName");
        String recvTel = request.getParameter("recvTel");
        String recvAddr = request.getParameter("recvAddr");
        String beizhu = request.getParameter("beizhu");

//        boolean sendcheckEmpty = UtilString.checkEmpty(sendName, sendTel, sendAddr);
//        boolean recvcheckEmpty = UtilString.checkEmpty(recvName,recvTel,recvAddr);
//        if (!sendcheckEmpty){
//            request.setAttribute("error","发件人信息不能为空");
//        }
//        if (!recvcheckEmpty){
//            request.setAttribute("error","收件人信息不能为空");
//        }
//        boolean sendnamelength = UtilString.checkLength(sendName, 3, 10);
//        boolean sendtellength = UtilString.checkLength(sendName, 7, 11);
//        boolean sendaddrlength = UtilString.checkLength(sendName, 10, 30);
//        if (!sendnamelength){
//            request.setAttribute("eroor","发件人姓名长度错误");
//            return;
//        }
//        if (!sendtellength){
//            request.setAttribute("error","发件人电话长度错误");
//            return;
//        }
//        if (!sendaddrlength){
//            request.setAttribute("error","发件人地址长度错误");
//            return;
//        }
//        boolean recvnamelength = UtilString.checkLength(recvName, 3, 10);
//        boolean recvtellength = UtilString.checkLength(recvTel, 7, 10);
//        boolean recvaddrlength = UtilString.checkLength(recvAddr, 10, 30);
//        if (!recvnamelength){
//            request.setAttribute("eroor","收件人姓名长度错误");
//            return;
//        }
//        if (!recvtellength){
//            request.setAttribute("eroor","收件人电话长度错误");
//            return;
//        }
//        if (!recvaddrlength){
//            request.setAttribute("eroor","收件人地址长度错误");
//            return;
//        }

        User userName = (User) request.getSession().getAttribute("userName");

        Order order = new Order(sendName, sendTel, sendAddr, recvName, recvTel, recvAddr, beizhu, userName.getUid());

        boolean b = orderService.insertOrder(order);
        if (b) {
            resultInfo = "添加订单成功";
            request.setAttribute("resultInfo", resultInfo);
            request.getRequestDispatcher("/menu.jsp").forward(request, response);
        }else {
            resultInfo = "添加订单失败";
            request.setAttribute("resultInfo", resultInfo);
            request.getRequestDispatcher("/menu.jsp").forward(request, response);
        }

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
