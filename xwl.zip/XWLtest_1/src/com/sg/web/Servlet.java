package com.sg.web;

import com.sg.domain.User;
import com.sg.service.LoginResultBean;
import com.sg.service.UserService;
import com.sg.service.UserServiceImpl;
import com.sg.util.UtilString;
import com.sg.util.Util_c3p0;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by Kiss on 2018/11/25 0025.
 */
@WebServlet(name = "Servlet")
public class Servlet extends HttpServlet {

    UserService userService = new UserServiceImpl();

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        String username = request.getParameter("username");
        String password = request.getParameter("userpwd");
        String mian = request.getParameter("mian");

//                request.getSession().setAttribute("name",resultSet.getString(2));
//                if(username.equals(resultSet.getString(2)) && userpwd.equals(resultSet.getString(3))) {
//                    if (mian != null && "yes".equals(mian)) {
//                        Cookie cookieName = new Cookie("nameKey", username);
//                        Cookie cookieMian = new Cookie("mian", mian);
//                        cookieMian.setMaxAge(60 * 60 * 24 * 7);
//                        cookieName.setMaxAge(60 * 60 * 24 * 7);
//                        response.addCookie(cookieMian);
//                        response.addCookie(cookieName);
//                    }
//                }

        LoginResultBean loginResultBean = userService.doLogin(username, password);
        if (loginResultBean.isSuccess()) {
            request.getSession().setAttribute("userName",loginResultBean.getUser());
            request.getRequestDispatcher("/menu.jsp").forward(request,response);
        }else {
            request.setAttribute("resultInfo",loginResultBean.getErrorInfo());
            request.getRequestDispatcher("/index.jsp").forward(request,response);
        }


    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}
