package com.sg.web;


import com.sg.domain.Order;
import com.sg.domain.User;
import com.sg.service.OrderService;
import com.sg.service.OrderServiceImpl;
import com.sg.util.Util_c3p0;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Kiss on 2018/11/26 0026.
 */
public class ShowServlet extends HttpServlet {

    OrderService orderService = new OrderServiceImpl();

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        User name = (User) request.getSession().getAttribute("userName");
        String pageNow = request.getParameter("pageNow");

        long totalPage = orderService.getUserPageNum(name.getUid());


        List<Order> orders =orderService.getPageOrder(name.getUid(), pageNow);

            request.setAttribute("orders",orders);
            request.setAttribute("totalPage",totalPage);
            request.setAttribute("pageNow",pageNow);

        System.out.println(orders);
            request.getRequestDispatcher("/showorder.jsp").forward(request,response);


    }
}
