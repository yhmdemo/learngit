package com.sg.domain;

/**
 * Created by Kiss on 2018/11/26 0026.
 */
public class Order {
    private Integer orderid;
    private String sendName;
    private String sendTel;
    private String sendAddr;
    private String recvName;
    private String recvTel;
    private String recvAddr;
    private String beizhu;
    private int user;

    public Integer getOrderid() {
        return orderid;
    }

    public void setOrderid(int orderid) {
        this.orderid = orderid;
    }

    public String getSendName() {
        return sendName;
    }

    public void setSendName(String sendName) {
        this.sendName = sendName;
    }

    public String getSendTel() {
        return sendTel;
    }

    public void setSendTel(String sendTel) {
        this.sendTel = sendTel;
    }

    public String getSendAddr() {
        return sendAddr;
    }

    public void setSendAddr(String sendAddr) {
        this.sendAddr = sendAddr;
    }

    public String getRecvName() {
        return recvName;
    }

    public void setRecvName(String recvName) {
        this.recvName = recvName;
    }

    public String getRecvTel() {
        return recvTel;
    }

    public void setRecvTel(String recvTel) {
        this.recvTel = recvTel;
    }

    public String getRecvAddr() {
        return recvAddr;
    }

    public void setRecvAddr(String recvAddr) {
        this.recvAddr = recvAddr;
    }

    public String getBeizhu() {
        return beizhu;
    }

    public void setBeizhu(String beizhu) {
        this.beizhu = beizhu;
    }

    public int getUser() {
        return user;
    }

    public void setUser(int user) {
        this.user = user;
    }

    public Order() {
    }

    public Order(String sendName, String sendTel, String sendAddr, String recvName, String recvTel, String recvAddr, String beizhu, int user) {
        this.sendName = sendName;
        this.sendTel = sendTel;
        this.sendAddr = sendAddr;
        this.recvName = recvName;
        this.recvTel = recvTel;
        this.recvAddr = recvAddr;
        this.beizhu = beizhu;
        this.user = user;
    }

    public Order(Integer uid) {
    }
}
