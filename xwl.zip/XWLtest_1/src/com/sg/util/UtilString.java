package com.sg.util;

/**
 * Created by Kiss on 2018/11/25 0025.
 */
public class UtilString {
    public static boolean checkEmpty(String...strs){
        if (strs==null){
            return false;
        }
        for (String str:strs) {
            if (str==null || "".equals(str)){
                return false;
            }
        }
        return true;
    }
    public static boolean checkLength(String str, int minlength, int maxlength){
        if (str.length()>maxlength || str.length()<minlength){
            return false;
        }
        return true;
    }
}
