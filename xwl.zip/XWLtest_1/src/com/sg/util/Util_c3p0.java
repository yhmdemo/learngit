package com.sg.util;

import com.mchange.v2.c3p0.ComboPooledDataSource;

import java.sql.*;

/**
 * Created by Kiss on 2018/11/25 0025.
 */
public class Util_c3p0 {
    public static ComboPooledDataSource dataSource=new ComboPooledDataSource();
    public static Connection connection(){
        try {
            Connection connection=dataSource.getConnection();
            return connection;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    public static void release(Connection connection,Statement statement){
        release(connection,statement,null);
    }
    public static void release(Connection connection, Statement statement,ResultSet resultSet){
        if (connection!=null){
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (statement!=null){
            try {
                statement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (resultSet!=null){
            try {
                resultSet.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
