package com.sg.service;

import com.sg.cache.OrderCache;
import com.sg.common.CommonConstant;
import com.sg.dao.OrderDao;
import com.sg.domain.Order;
import com.sg.util.UtilString;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class OrderServiceImpl implements OrderService{

    @Resource
    private OrderDao orderDao;

    @Autowired
    private OrderCache orderCache;


    private Logger logger = Logger.getLogger(OrderServiceImpl.class);


    public boolean insertOrder(Order order) {

        boolean addOrder = orderDao.addOrder(order);
        if (addOrder) {
            orderCache.deleteOrders(order.getUser());
        }

        return addOrder;
//        if (addOrder == true) {
//            return true;
//        } else {
//            return false;
//        }
    }

    public long getUserPageNum(int userid) {
        if (userid<=0) {
            return 0;
        }

        Long pageNum = orderCache.queryPageNum(userid);
        if (pageNum==null) {
//            logger.error("缓存中没有，去数据库查询");
            System.out.println("缓存中没有，去数据库查询");
            pageNum = orderDao.queryUserPageNum(userid);

                orderCache.savepageNum(userid,pageNum);
//                logger.error("数据库中有，放入缓存");
                System.out.println("数据库中有，放入缓存");
        }

        long totalPage = (long) Math.ceil(pageNum*1.0/CommonConstant.COUNT_A);

        return totalPage;
    }


    public List<Order> getPageOrder(int userid, String pageNow) {
        if (userid<=0){
            return null;
        }

        if (!UtilString.checkEmpty(pageNow)){
            pageNow = "1";
        }

        int startPos = (Integer.parseInt(pageNow)-1)* CommonConstant.COUNT_A;

        List<Order> orders = orderCache.queryPartOrders(userid, startPos, CommonConstant.COUNT_A);
        if (orders==null) {
            System.out.println("缓存中没有，去数据库查询");
            List<Order> allOrder = orderDao.queryAllOrder(userid);
            if (allOrder!=null) {
                orderCache.saveAllOrders(userid,allOrder);
                System.out.println("查询全部数据，存到缓存中");
                orders = orderCache.queryPartOrders(userid, startPos, CommonConstant.COUNT_A);
            }
        }else {
            System.out.println("缓存中有数据");
        }


        return orders;
    }
}
