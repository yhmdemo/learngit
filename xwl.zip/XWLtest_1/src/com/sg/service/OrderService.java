package com.sg.service;

import com.sg.domain.Order;

import java.util.List;

public interface OrderService {
    public boolean insertOrder(Order order);

//    查询指定用户的订单页数
    public long getUserPageNum(int userid);

//    查询指定用户的单页订单
    public List<Order> getPageOrder(int userid,String pageNow);
}
