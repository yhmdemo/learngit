package com.sg.service;

public interface UserService {
    public LoginResultBean doLogin(String username,String password);

}
