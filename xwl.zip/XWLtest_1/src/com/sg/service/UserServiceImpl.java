package com.sg.service;

import com.sg.cache.UserCache;
import com.sg.dao.UserDao;
import com.sg.domain.User;
import com.sg.util.UtilString;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class UserServiceImpl implements UserService {

    @Resource
    private UserDao userDao;

    @Autowired
    private UserCache userCache;

    private Logger logger = Logger.getLogger(UserServiceImpl.class);

    public LoginResultBean doLogin(String username, String password) {

        LoginResultBean loginResultBean =new LoginResultBean();

        boolean checkEmpty = UtilString.checkEmpty(username, password);
        if (!checkEmpty){
            loginResultBean.setSuccess(false);
            loginResultBean.setErrorInfo("用户名密码不能为空");

            return loginResultBean;
        }

        boolean namelength = UtilString.checkLength(username, 3, 6);
        boolean pwdlength = UtilString.checkLength(password, 4, 8);
        if (!namelength || !pwdlength){
            loginResultBean.setSuccess(false);
            loginResultBean.setErrorInfo("用户名密码长度错误");

            return loginResultBean;
        }


        User user = userCache.queryUserBynameAndpwd(username, password);
        if (user==null){
            logger.error("缓存中没有，去数据库查询");
            user = userDao.queryUserByUnameAndUpwd(username, password);
            if (user!=null){
                userCache.saveUserBynameAndpwd(user);
                logger.error("数据库中有，放入缓存");
            }
        }else {
            logger.error("缓存中有，直接使用");
        }



        if (user==null) {
            loginResultBean.setSuccess(false);
            loginResultBean.setErrorInfo("用户名密码不正确");
            return loginResultBean;
        }
        loginResultBean.setSuccess(true);
        loginResultBean.setUser(user);


        return loginResultBean;
    }
}
