package com.sg.dao;

import com.sg.domain.User;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

@Repository
public interface UserDao {

    @Select("SELECT * FROM user WHERE username=#{username} AND password=#{password}")
    public User queryUserByUnameAndUpwd(@Param("username") String username,@Param("password") String password);
}
