package com.sg.dao;

import com.sg.domain.Order;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OrderDao {

    @Insert("INSERT INTO t_order VALUES (null,#{sendName},#{sendTel},#{sendAddr}," +
            "#{recvName},#{recvTel},#{recvAddr},#{beizhu},#{user})")
    public boolean addOrder(Order order);

    @Select("SELECT COUNT(*) FROM t_order WHERE user=#{userid}")
    public long queryUserPageNum(int userid);

    @Select("SELECT * FROM t_order WHERE USER=#{userid} LIMIT #{startPos},#{count}")
    public List<Order> queryOrderPageByPageNum(@Param("userid") int userid,@Param("startPos") int startPos,@Param("count") int count);

    @Select("SELECT * FROM t_order WHERE USER=#{userid}")
    public List<Order> queryAllOrder(@Param("userid") int userid);
}
