package com.sg.controller;

import com.sg.service.LoginResultBean;
import com.sg.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("userCenter")
public class UserController {

    @Resource
    private UserService userService;

    @RequestMapping("login")
    public String login(String username, String userpwd, HttpSession session, Model model){

        LoginResultBean loginResultBean = userService.doLogin(username, userpwd);

        if (loginResultBean.isSuccess()) {
            session.setAttribute("userName",loginResultBean.getUser());
            return "menu";
        }else {
            model.addAttribute("resultInfo",loginResultBean.getErrorInfo());
            return "redirect:/index.jsp";
        }
    }
}
