package com.sg.controller;

import com.sg.domain.Order;
import com.sg.domain.User;
import com.sg.service.OrderService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping("orderCenter")
public class OrderController {

    @Resource
    private OrderService orderService;
    String resultInfo = "";

    @RequestMapping("orders")
    public String orders(){
        return "addorder";
    }

    @RequestMapping("addOrder")
    public String addOrder(Order order, HttpSession session,Model model){

        User userName = (User) session.getAttribute("userName");
        order.setUser(userName.getUid());
        boolean b = orderService.insertOrder(order);
        if (b) {
            resultInfo = "添加订单成功";
            model.addAttribute("resultInfo", resultInfo);
            return "menu";
        }else {
            resultInfo = "添加订单失败";
            model.addAttribute("resultInfo", resultInfo);
            return "menu";
        }
    }

    @RequestMapping("showOrder")
    public String showOrder(HttpSession session,String pageNow,Model model){
        User name = (User) session.getAttribute("userName");
        long totalPage = orderService.getUserPageNum(name.getUid());
        List<Order> orders =orderService.getPageOrder(name.getUid(), pageNow);

        model.addAttribute("orders",orders);
        model.addAttribute("totalPage",totalPage);
        model.addAttribute("pageNow",pageNow);

        return "showorder";
    }

    @RequestMapping("menu")
    public String menu(){
        return "menu";
    }
}
