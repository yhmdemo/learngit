package com.sg.cache;

import com.google.gson.Gson;
import com.sg.domain.User;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component
public class UserCache {

    @Resource
    private RedisTemplate redisTemplate;
    private Gson gson = new Gson();

//    根据用户名密码在缓存中查询
    public User queryUserBynameAndpwd(String username,String password){
        String key = "user_"+username+"_"+password;
        ValueOperations valueOperations = redisTemplate.opsForValue();
        Object o = valueOperations.get(key);
        if (o==null){
            return null;
        }else {
            String json = String.valueOf(o);
            User user = gson.fromJson(json, User.class);
            return user;
        }

    }

//    把用户存到缓存中
    public void saveUserBynameAndpwd(User user){
        String username = user.getUsername();
        String password = user.getPassword();
        String key = "user_"+username+"_"+password;
        ValueOperations valueOperations = redisTemplate.opsForValue();
        String json = gson.toJson(user);
        valueOperations.set(key,json);
    }
}
