package com.sg.cache;

import com.google.gson.Gson;
import com.sg.domain.Order;
import com.sg.domain.User;
import org.springframework.data.redis.core.ListOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@Component
public class OrderCache {

    @Resource
    private RedisTemplate redisTemplate;
    private Gson gson = new Gson();

    public Long queryPageNum(int userid){
        String key = "orderCount:"+userid;
        ValueOperations valueOperations = redisTemplate.opsForValue();
        Object o = valueOperations.get(key);
        if (o==null) {
            return null;
        }
        long count = Long.parseLong(o.toString());
        return count;
    }

    public void savepageNum(int userid,Long pageNum){
        String key = "orderCount:"+userid;
        ValueOperations valueOperations = redisTemplate.opsForValue();
        valueOperations.set(key,String.valueOf(pageNum));
    }

    public List<Order> queryPartOrders(int userid,int startOps,int count){
        String key = "addOrders:"+userid;
        ListOperations listOperations = redisTemplate.opsForList();
        List list = listOperations.range(key, startOps, (startOps + count - 1));
        if (list==null || list.size()==0) {
            return null;
        }
        List<Order> orders = new ArrayList<>();
        for (Object o : list) {
            String s = String.valueOf(o);
            orders.add(gson.fromJson(s,Order.class));
        }
        return orders;
    }

    public void saveAllOrders(int userid,List<Order> orders){
        String key = "addOrders:"+userid;
        ListOperations listOperations = redisTemplate.opsForList();
        for (Order order:orders){
            listOperations.rightPush(key,gson.toJson(order));
        }
    }

    public void deleteOrders(int userid){
        String key1 = "orderCount:"+userid;
        String key2 = "addOrders:"+userid;
        redisTemplate.delete(key1);
        redisTemplate.delete(key2);
    }
}
